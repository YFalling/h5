﻿
U Picture - by Y.FALLING

版本 17.5.12

HTML框架、css样式和js控制，图片每6秒切换一次，同步切换文字。

点击圆圈播放，点击全屏暂停并显示A4工作室。

半响应式布局，最佳尺寸为iPhone 6尺寸375*667。

U Picture最大宽度为500px，内容响应式居中，当高度设备高度不够时自动切换为滚动模式。

U Picture固定比例为 1 ： 1.78

Copyright © 2017 Y.FALLING. All Rights Reserved.
Create by Yu.
